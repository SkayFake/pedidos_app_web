<?php

namespace App\Filament\Resources\Zones;

use App\Filament\Resources\Zones\Pages\CreateZone;
use App\Filament\Resources\Zones\Pages\EditZone;
use App\Filament\Resources\Zones\Pages\ListZones;
use App\Filament\Resources\Zones\Schemas\ZoneForm;
use App\Filament\Resources\Zones\Tables\ZonesTable;
use App\Models\Zone;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class ZoneResource extends Resource
{
    protected static ?string $model = Zone::class;

    // Icono de mapa para zonas
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedMapPin;

    // Traducción en el menú lateral
    protected static ?string $navigationLabel = 'Zonas';

    // Traducción para los botones (Ej: "Crear Zona")
    protected static ?string $modelLabel = 'Zona';
    protected static ?string $pluralModelLabel = 'Zonas';

    // Agrupación en el menú lateral
    protected static string | \UnitEnum | null $navigationGroup = 'Administración';

    protected static ?string $recordTitleAttribute = 'name';

    public static function canAccess(): bool
    {
        $user = auth('admin')->user();
        return $user && $user->isSuperAdmin();
    }

    public static function form(Schema $schema): Schema
    {
        return ZoneForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return ZonesTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListZones::route('/'),
        ];
    }
}
